<?php
/**
 * @author JoomlaShine.com Team
 * @copyright JoomlaShine.com
 * @link joomlashine.com
 * @package JSN VideoShow
 * @version $Id: view.html.php 10238 2011-12-14 08:09:07Z giangnd $
 * @license GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined('_JEXEC') or die( 'Restricted access' );
jimport( 'joomla.application.component.view');
class ImageShowViewImages extends JViewLegacy
{
	function display($tpl = null)
	{
		parent::display($tpl);
	}
}
?>